/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.ServiciosDatos;

import com.proyecto.Entidades.Ofertas;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author empre
 */
public class DatosOfertas extends AccesoDatos {

    private PreparedStatement prepared = null;
    private ResultSet result = null;

    public List<Ofertas> leerOferta(String filtroNombre, String filtroEmpresa, String filtroUbicacion) {
    List<Ofertas> listaRetorno = new ArrayList<>();

    try {
        super.Conectar();

        // Consulta SQL con filtros
        String sql = "SELECT o.idOferta, o.nombrePuesto, e.nombreEmpresa, p.nombreProvincia, o.logo "
                   + "FROM ofertas o "
                   + "JOIN empresas e ON o.idEmpresa = e.idEmpresa "
                   + "JOIN provincia p ON e.idProvincia = p.idProvincia "
                   + "WHERE (? = '' OR o.nombrePuesto LIKE ?) "
                   + "AND (? = '' OR e.nombreEmpresa LIKE ?) "
                   + "AND (? = '' OR p.nombreProvincia LIKE ?)";

        this.prepared = super.getConector().prepareStatement(sql);

        // Asignar valores a los parámetros de la consulta
        this.prepared.setString(1, filtroNombre);
        this.prepared.setString(2, "%" + filtroNombre + "%");
        this.prepared.setString(3, filtroEmpresa);
        this.prepared.setString(4, "%" + filtroEmpresa + "%");
        this.prepared.setString(5, filtroUbicacion);
        this.prepared.setString(6, "%" + filtroUbicacion + "%");

        this.result = prepared.executeQuery();

        while (this.result.next()) {
            Ofertas objOfertas = new Ofertas();
            objOfertas.setIdOferta(result.getInt("o.idOferta"));
            objOfertas.setNombrePuesto(result.getString("o.nombrePuesto"));
            objOfertas.setEmpresa(result.getString("e.nombreEmpresa"));
            objOfertas.setUbicacion(result.getString("p.nombreProvincia"));
            objOfertas.setImagenOferta(result.getString("o.logo"));

            listaRetorno.add(objOfertas);
        }

    } catch (ClassNotFoundException | SQLException e) {
        System.out.print(e);
    } finally {
        cerrarConexion();
        cerrarPrepared(this.prepared);
        cerrarResult(this.result);
    }
    return listaRetorno;
}
}
