> [!WARNING]
> Recuenden que la base de datos aun las seguimos manejando en remoto para que cambien la tabla y la constraseña en la clase AccesoDatos para evitar problemas

> [!NOTE]
> Recuerden agregar el resto de atributos en la clase usuario para los que vayan a trabajar con la clase usuario


> [!IMPORTANT]
> Recuenden cambiar el query en la clase DatosUsuarios


